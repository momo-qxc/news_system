create definer = root@localhost view v_theme_news as
select (select `t`.`tname` from `news_system`.`tb_theme` `t` where (`t`.`tid` = `n`.`tid`)) AS `tname`,
       count(`n`.`tid`)                                                                     AS `cnt`
from `news_system`.`tb_news` `n`
group by `n`.`tid`;

